// Frases de las mascotas. {n} = ", Nombre" (si lo configuraste), {t} = título de la canción/radio.
export const pick = (list) => list[Math.floor(Math.random() * list.length)];

export const GREET = {
  morning: ['¡Buenos días{n}!', 'Arriba{n}, ya amaneció.', '¡Buen día{n}! ¿Ya tomaste tinto?', 'Hoy se puede{n}, vamos con toda.'],
  afternoon: ['¡Buenas tardes{n}!', 'Sigamos{n}, la tarde apenas empieza.', '¡Hola{n}! ¿Cómo va el día?', 'Aquí sigo{n}, ¿qué hacemos?'],
  evening: ['¡Buenas noches{n}!', 'Ya casi terminas{n}, ánimo.', 'Hora de ir bajando el ritmo{n}.', '¡Hola{n}! Qué bueno verte por aquí.'],
};

// Comentarios según la hora (se usan de vez en cuando).
export const byHour = (h) => {
  if (h >= 5 && h < 9) return ['Un buen desayuno y arrancamos.', 'La mañana es tuya.'];
  if (h >= 11 && h < 14) return ['¿Ya almorzaste? No te saltes la comida.', 'Se acerca la hora del almuerzo.'];
  if (h >= 14 && h < 17) return ['Pausa corta: estírate un poquito.', 'Toma agüita, que se te olvida.'];
  if (h >= 17 && h < 21) return ['Se acabó la jornada… casi.', 'La tarde se va, ¿ya descansaste los ojos?'];
  if (h >= 21 && h < 23) return ['Ya es tarde, no te desveles{n}.', 'Una canción tranquila y a descansar.'];
  return ['Es de madrugada… ¿no deberías dormir?', 'Los búhos como yo también trasnochamos.'];
};

export const FUN = [
  'Estoy aquí por si me necesitas.', 'Arrástrame por la pantalla, no muerdo.', 'Toma agüita, ¿sí?', 'Endereza la espalda, campeón.',
  '¿Un descanso de dos minutos?', 'Parpadea un poquito, descansa la vista.', '¡Tócame! Me gustan los mimos.', 'Qué bonita está tu app, ¿no?',
  'Si me cargas, prometo no pesar.', 'Todo está en orden por aquí.',
];

export const WEATHER = {
  rain: [
    '¡Está lloviendo! No olvides el paraguas.', 'Cae agüita… qué rico un tinto caliente.', 'Lluvia afuera, música adentro.',
    'Ese aguacero no perdona, lleva sombrilla.', 'Con esta lluvia mejor maratón de series.', 'Suena a lluvia con tinto, plan perfecto.',
  ],
  hot: [
    'Qué calor… ¡hidrátate!', 'Me derrito. Busquemos sombra.', 'Hace un solazo, toma agua.',
    'Ni los lagartos aguantan este sol.', 'Busca sombra que te vas a cocinar.', 'Agüita fría ya, que esto está bravo.',
  ],
  cold: [
    'Brrr, qué frío. Abrígate.', 'Hace fresquito, ponte algo encima.', 'Qué frío… ¿tienes chaqueta?',
    'Saca la cobija que esto se puso serio.', 'Un chocolatico caliente caería bien.', 'Hasta yo me puse bufanda.',
  ],
  sun: [
    'Qué día tan lindo, aprovéchalo.', 'Hoy el sol está de buenas.', 'Cielo limpio, ¡a salir un rato!',
    'Día de esos que dan ganas de pasear.', 'Solcito rico, sal a tomar el fresco.', 'Qué cielo tan azul, ni una nube chismosa.',
  ],
  night: ['Linda noche, ¿viste las estrellas?', 'Noche despejada, qué paz.', 'Noche clara, perfecta para soñar.'],
  cloud: ['Cielo tapado, plan tranquilo.', 'Todo gris y calmado hoy.', 'Día gris, ideal para estar en casa.'],
  fog: ['Hay neblina, ve con cuidado.', 'Se ve todo borroso afuera.', 'Con esta niebla ni los gatos ven.'],
  storm: [
    '¡Truenos! Yo me escondo debajo de la cama.', 'Está tronando feo, mejor adentro.',
    'Desconecta todo que eso viene con fuerza.', 'Qué miedo esos rayos, abrázame.',
  ],
  uv: [
    'Ponte bloqueador, yo ya me puse el mío. Bueno, no tengo piel, pero tú sí.',
    'Ese sol quema, no salgas sin protección.', 'UV altísimo: gorra, gafas y bloqueador.',
    'Con este sol hasta yo uso sombrilla.',
  ],
};

export const MUSIC = [
  'Suena «{t}». ¡Qué buen gusto!', '«{t}»… súbele que está buena.', '¡Me encanta «{t}»!', 'A bailar con «{t}».',
];
export const WAKE = ['¡Ya desperté!', 'Mmm… ¿me perdí algo?', '¡Volviste! Te esperaba.', 'Zzz… ¿eh? ¡Presente!'];
export const POKE = ['¡Jeje, cosquillas!', '¡Me gustas tú también!', '¿Otra vez? ¡Me encanta!', '¡Hola, hola!', '¡Aquí estoy!', 'Ñam… digo, ¡hola!'];
export const DIZZY = ['¡Ya, ya! Me mareo…', '¡Tranquilo, tranquilo!', 'Uf, dame un respiro.'];
export const PICKED_UP = ['¡Wooah!', '¡Me levantaste!', '¡Bájame con cariño!', '¡Qué altura!'];
